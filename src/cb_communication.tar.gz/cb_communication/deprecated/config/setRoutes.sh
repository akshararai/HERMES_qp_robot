#!/bin/bash

./rtroute add 192.168.2.1 0:0:0:22:34:56 dev rteth1
./rtroute add 192.168.2.2 0:0:0:22:34:57 dev rteth1
./rtroute add 192.168.2.3 0:0:0:22:34:58 dev rteth1
./rtroute add 192.168.2.4 0:0:0:22:34:59 dev rteth1
./rtroute add 192.168.2.5 0:0:0:22:34:5A dev rteth1
./rtroute add 192.168.2.6 0:0:0:22:34:5B dev rteth1
./rtroute add 192.168.2.7 0:0:0:22:34:5C dev rteth1
./rtroute add 192.168.2.8 0:0:0:22:34:5D dev rteth1
./rtroute add 192.168.2.9 0:0:0:22:34:5E dev rteth1

./rtroute add 192.168.3.1 0:0:0:22:34:56 dev rteth2
./rtroute add 192.168.3.2 0:0:0:22:34:57 dev rteth2
./rtroute add 192.168.3.3 0:0:0:22:34:58 dev rteth2
./rtroute add 192.168.3.4 0:0:0:22:34:59 dev rteth2
./rtroute add 192.168.3.5 0:0:0:22:34:5A dev rteth2
./rtroute add 192.168.3.6 0:0:0:22:34:5B dev rteth2
./rtroute add 192.168.3.7 0:0:0:22:34:5C dev rteth2
./rtroute add 192.168.3.8 0:0:0:22:34:5D dev rteth2
./rtroute add 192.168.3.9 0:0:0:22:34:5E dev rteth2

./rtroute add 192.168.4.1 0:0:0:22:34:56 dev rteth3
./rtroute add 192.168.4.2 0:0:0:22:34:57 dev rteth3
./rtroute add 192.168.4.3 0:0:0:22:34:58 dev rteth3
./rtroute add 192.168.4.4 0:0:0:22:34:59 dev rteth3
./rtroute add 192.168.4.5 0:0:0:22:34:5A dev rteth3
./rtroute add 192.168.4.6 0:0:0:22:34:5B dev rteth3
./rtroute add 192.168.4.7 0:0:0:22:34:5C dev rteth3
./rtroute add 192.168.4.8 0:0:0:22:34:5D dev rteth3
./rtroute add 192.168.4.9 0:0:0:22:34:5E dev rteth3

./rtroute add 192.168.5.1 0:0:0:22:34:56 dev rteth0
./rtroute add 192.168.5.2 0:0:0:22:34:57 dev rteth0
./rtroute add 192.168.5.3 0:0:0:22:34:58 dev rteth0
./rtroute add 192.168.5.4 0:0:0:22:34:59 dev rteth0
./rtroute add 192.168.5.5 0:0:0:22:34:5A dev rteth0
./rtroute add 192.168.5.6 0:0:0:22:34:5B dev rteth0
./rtroute add 192.168.5.7 0:0:0:22:34:5C dev rteth0
./rtroute add 192.168.5.8 0:0:0:22:34:5D dev rteth0
./rtroute add 192.168.5.9 0:0:0:22:34:5E dev rteth0


