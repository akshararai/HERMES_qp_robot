import numpy as np
import matplotlib.pyplot as plt
from py_kalman_vs_butter.clmcplot_utils import ClmcFile

class FailureHints:

    def __init__(self, dfile=None):
        self.dfile=dfile
        self.base_slck_varnames=['BASE_slck_x', 'BASE_slck_y', 'BASE_slck_z', 'BASE_slck_a', 'BASE_slck_b', 'BASE_slck_g' ]
        self.swingfoot_right_slck_varnames=['R_FOOT_slck_x', 'R_FOOT_slck_y', 'R_FOOT_slck_z', 'R_FOOT_slck_a', 'R_FOOT_slck_b', 'R_FOOT_slck_g' ]
        self.swingfoot_left_slck_varnames=['L_FOOT_slck_x', 'L_FOOT_slck_y', 'L_FOOT_slck_z', 'L_FOOT_slck_a', 'L_FOOT_slck_b', 'L_FOOT_slck_g' ]
        self.momrate_slck_varnames=['MomRate_slck_x','MomRate_slck_y','MomRate_slck_z','MomRate_slck_a','MomRate_slck_b','MomRate_slck_g']
        pass
    
    def open_log(self, filename):
        self.dfile=ClmcFile(filename)
        return

    def plot_slacks(self, plot_range = None):
        dc_time=self.dfile.get_variables('time')
        if plot_range == None:
            plot_range = np.s_[:]
        else:
            dt=dc_time[1]-dc_time[0]
            plot_range=np.s_[int(plot_range[0]/dt):int(plot_range[1]/dt)]

        walking_state=self.dfile.get_variables('walking_state')

        base_slacks=self.dfile.get_variables(self.base_slck_varnames)
        base_slack_sqr_sum=np.zeros(base_slacks[0].size)
        for i in range(len(base_slacks)): 
            base_slack_sqr_sum += base_slacks[i]**2

        swingfoot_right_slacks=self.dfile.get_variables(self.swingfoot_right_slck_varnames)
        swingfoot_right_slack_sqr_sum=np.zeros(swingfoot_right_slacks[0].size)
        for i in range(len(swingfoot_right_slacks)): 
            swingfoot_right_slack_sqr_sum += swingfoot_right_slacks[i]**2


        swingfoot_left_slacks=self.dfile.get_variables(self.swingfoot_left_slck_varnames)
        swingfoot_left_slack_sqr_sum=np.zeros(swingfoot_left_slacks[0].size)
        for i in range(len(swingfoot_left_slacks)): 
            swingfoot_left_slack_sqr_sum += swingfoot_left_slacks[i]**2

        posture_slacks_sqr_sum=self.dfile.get_variables('posture_slck')

        momrate_slacks=self.dfile.get_variables(self.momrate_slck_varnames)
        momrate_slacks_sqr_sum=np.zeros(momrate_slacks[0].size)
        for i in range(len(momrate_slacks)): 
            momrate_slacks_sqr_sum += momrate_slacks[i]**2

        feet_const_slacks_sqr_sum=self.dfile.get_variables('stat_feet_slck')
        
        plt.subplot(2,1,1)
        plt.plot(dc_time[plot_range], base_slack_sqr_sum[plot_range], label='BASE slack')
        plt.plot(dc_time[plot_range], feet_const_slacks_sqr_sum[plot_range], label='feet_const slack')
        plt.plot(dc_time[plot_range], momrate_slacks_sqr_sum[plot_range], label='MomRate slack')
        plt.plot(dc_time[plot_range], posture_slacks_sqr_sum[plot_range], label='posture slack')
        plt.plot(dc_time[plot_range], swingfoot_right_slack_sqr_sum[plot_range], label='SwingRight slack')
        plt.plot(dc_time[plot_range], swingfoot_left_slack_sqr_sum[plot_range], label='SwingLeft slack')
        plt.legend()

        plt.subplot(2,1,2)
        plt.plot(dc_time[plot_range], walking_state[plot_range], label='walking state')
        plt.legend()
