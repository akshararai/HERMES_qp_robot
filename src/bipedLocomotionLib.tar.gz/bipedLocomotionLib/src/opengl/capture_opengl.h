/*
 * capture_opengl.h
 *
 *  Created on: May 21, 2013
 *      Author: righetti
 */

#ifndef CAPTURE_OPENGL_H_
#define CAPTURE_OPENGL_H_


#ifdef __cplusplus
extern "C" {
#endif

extern void captureFrame(void *buf);

#ifdef __cplusplus
}
#endif

#endif /* CAPTURE_OPENGL_H_ */
